package com.example1;

public class Example2 {

	public void hi1() {
		System.out.println("Hi11");
		hello1();
	}

	private void hello1() {
		System.out.println("hello111");
	}

	protected void print1() {
		System.out.println("print111");
	}

	void display1() {
		System.out.println("display111");
	}
}

package com.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentNikithaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentNikithaProjectApplication.class, args);
	}

}

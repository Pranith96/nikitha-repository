
public class MainMethod {

	public static void main(String[] args) {
		Summation sm = new Summation();
		sm.add(20, 10);
		String result = sm.hello("Java");
		System.out.println(result);
	}
}
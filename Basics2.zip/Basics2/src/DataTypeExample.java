
public class DataTypeExample {

	public void data() {
		char c  = 'a';
		byte b = 10;
		long l = 1000l;
		double d = 567.9d;
		float f = 198.5f;
		int i = 10;
		boolean bb = true;
		short s = 12;
		
		System.out.println(c+ " " +b+ " "+l);
	}
}

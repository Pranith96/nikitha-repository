
public class Addition {

	public void add(int a, int b) {
		System.out.println(a + b);
	}

	public void add(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	public long add(int a, int b, long c) {
		return a + b + c;
	}
}

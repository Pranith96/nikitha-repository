
public interface Bike1 {

	public void tire();
	public void engine();
	public void breakss();
	public void seat();
}


public abstract class Bike {

	public void engine() {
		System.out.println("engine");
	}
	
	public abstract void breakss();
	public abstract void tire();
}

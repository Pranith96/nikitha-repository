
public class MainMethod {

	public static void main(String[] args) {
		Bike3 bike = new Bike3();
		bike.petrolTank();
		bike.breakss();
		bike.engine();
		bike.mirror();
		bike.seat();
		bike.tire();
	}
}

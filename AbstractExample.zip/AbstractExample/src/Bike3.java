
public class Bike3 extends Bike2 {

	public void petrolTank() {
		System.out.println("petrol Tank");
	}
}

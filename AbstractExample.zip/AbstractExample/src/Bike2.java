
public abstract class Bike2 extends Bike1 {

	public void tire() {
		System.out.println("tire");
	}

	public abstract void petrolTank();

	public void seat() {
		System.out.println("seat");
	}
}

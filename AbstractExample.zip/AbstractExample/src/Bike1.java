
public abstract class Bike1 extends Bike {

	public void breakss() {
		System.out.println("breaks");
	}

	public abstract void tire();

	public void mirror() {
		System.out.println("mirror");
	}
}


public class AssignmentOperator {

	public static void main(String[] args) {

		int a = 10;
		int b = 10;

		a += b; // a= a+b;
		System.out.println(a);
		a -= b;
		a /= b;
		a %= b;
	}
}

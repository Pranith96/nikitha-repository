
public class ShiftOperator {

	public static void main(String[] args) {

		// left shift
		System.out.println(10 << 2); // 10*2^2 = 10*4 = 40
		System.out.println(10 << 3); // 10*2 ^3 = 80
		System.out.println(20 << 4); // 20*2 ^ 4 ==
		// right shift
		System.out.println(10 >> 2); // 10/2^2 == 2
		System.out.println(20>>3); // 20/2^3 == 2
	}
}

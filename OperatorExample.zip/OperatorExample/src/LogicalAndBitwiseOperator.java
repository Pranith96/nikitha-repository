
public class LogicalAndBitwiseOperator {

	public static void main(String[] args) {
		int a = 10;
		int b = 15;
		int c = 20;

		System.out.println(a > b && b < c);

		System.out.println(a > b || b < c);

		System.out.println(a > b | b < c);

	}
}

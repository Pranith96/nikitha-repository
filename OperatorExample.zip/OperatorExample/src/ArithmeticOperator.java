
public class ArithmeticOperator {

	public static void main(String[] args) {

		int a = 20;
		int b = 15;
		System.out.println(a+b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a-b);
		System.out.println(a%b);
	}
}


public class TernaryOperator {

	public static void main(String[] args) {

		int a = 5;
		int b = 10;

		int value = a < b ? a : b;
		System.out.println(value);
	}
}

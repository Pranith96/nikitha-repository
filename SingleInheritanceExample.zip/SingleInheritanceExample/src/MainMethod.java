
public class MainMethod {

	public static void main(String[] args) {
		Summation sm = new Summation();
		sm.sum(10, 10, 10);
		sm.add(10, 10);
		sm.display();

	}
}

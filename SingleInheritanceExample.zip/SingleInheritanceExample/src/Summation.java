
public class Summation extends Addition {

	public void sum(int a, int b, int c) {
		int d = a * b * c;
		System.out.println(d);
	}
}